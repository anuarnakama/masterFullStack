export interface INoticia {
    titulo: string;
    url: string;
    texto: string;
    fecha?: Date;
}
